package estruturasdedados.com.br.fatorial;

import java.util.Scanner;

public class PotenciaIterativa {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		int a = 0, b = 0, c = 0;
		a = scan.nextInt();
		b = scan.nextInt();
		c = a;
		
		for (int i = 1; i < b; i++) {
			
			a = a * c;
		}
		
		System.out.println(a);

	}

}
