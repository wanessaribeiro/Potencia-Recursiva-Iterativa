package estruturasdedados.com.br.fatorial;

import java.util.Scanner;

public class Fatorial {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int n;
		System.out.println("Insira aqui o n�mero: ");
		n = scan.nextInt();
		
		System.out.println("Resultado: " + fatorial(n));

	}
	
	public static int fatorial(int n) {
		
		if(n == 0 || n == 1) return 1;
		return n * (fatorial(n - 1));
	}

}
