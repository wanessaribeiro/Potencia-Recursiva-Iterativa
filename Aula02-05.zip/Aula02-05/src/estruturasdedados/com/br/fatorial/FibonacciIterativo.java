package estruturasdedados.com.br.fatorial;

import java.util.Scanner;

public class FibonacciIterativo {

	public static void main(String[] args) {

		int a = 0, b = 0, n = 0, p;
		Scanner scan = new Scanner(System.in);
		p = scan.nextInt();
		
		for (int i = 1; i <= p; i++) {
			
			a = b;
			b = n;
			n = a + b;
			
			if(i == 1) n = 1;
			
		}
		
		System.out.println(n);

	}

}
