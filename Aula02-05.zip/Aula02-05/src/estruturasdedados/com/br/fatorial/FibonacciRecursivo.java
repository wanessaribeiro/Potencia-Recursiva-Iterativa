package estruturasdedados.com.br.fatorial;

import java.util.Scanner;

public class FibonacciRecursivo {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		int n = 0;
		n = scan.nextInt();
		
		System.out.println(Fibonacci(n));

	}
	
	public static int Fibonacci(int n) {
		
		if(n == 0) return 0;
		if(n == 1) return 1;
		return Fibonacci(n - 1) + Fibonacci(n - 2);
	}
	

}
