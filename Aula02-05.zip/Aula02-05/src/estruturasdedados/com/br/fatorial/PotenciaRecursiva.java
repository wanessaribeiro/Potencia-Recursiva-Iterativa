package estruturasdedados.com.br.fatorial;

import java.util.Scanner;

public class PotenciaRecursiva {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		int a, b;
		
		a = scan.nextInt();
		b = scan.nextInt();
		
		System.out.println(Potencia(a, b));
		
	}
	
	public static int Potencia(int a, int b) {
		
		if(b == 0)return 1;
		if(b == 1)return a;
		return a * Potencia(a, b - 1);
	}

}
